from flask import Flask, request, render_template
import psycopg2
import os

app = Flask(__name__)

# Configurações do banco via variáveis de ambiente
DB_HOST = os.getenv("DB_HOST", "dpg-d0p7r2gdl3ps73ai14f0-a.oregon-postgres.render.com")
DB_NAME = os.getenv("DB_NAME", "biblioteca_5goo")
DB_USER = os.getenv("DB_USER", "milton")
DB_PASSWORD = os.getenv("DB_PASSWORD", "WGRmd6lgYcOWvECkuev4UU93DxBjENoH")
DB_PORT = os.getenv("DB_PORT", 5432)

def conectar_banco():
    return psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT
    )

@app.route('/')
def formulario():
    conn = conectar_banco()
    cur = conn.cursor()
    cur.execute("SELECT id_livro, titulo FROM livros")
    livros = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('reserva.html', livros=livros)

@app.route('/reservar', methods=['POST'])
def reservar():
    nome = request.form.get('nome')
    id_livro = request.form.get('id_livro')
    data = request.form.get('data')

    conn = conectar_banco()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO reservas (nome_usuario, id_livro, data_reserva)
        VALUES (%s, %s, %s)
    """, (nome, id_livro, data))
    conn.commit()
    cur.close()
    conn.close()

    return "Reserva registrada com sucesso!"

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0')
